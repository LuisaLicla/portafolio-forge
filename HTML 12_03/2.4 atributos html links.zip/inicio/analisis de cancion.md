# Trap, música y letra.

Trap fue el nombre se le dio a la mezcla de sonidos derivados del hip hop y la electrónica. Nació a finales de los años 90 en Estados Unidos. Se diferencia de otros géneros por su ritmo, arreglos electrónicos densos y sombríos. Puede ser muy lento y a la vez rápido. Lo importante no son las notas musicales, sino los efectos sonoros.

Las letras no tratan de dar ningún mensaje, solamente narran de forma explícita historias de lo que viven algunas personas en guetos, como el tráfico de drogas, riñas, armas, sexo, fiestas, excesos, dinero, marginalidad y decadencia. Fue denominado trap precisamente porque los exponentes se sentían una trampa de la que es difícil salir.

“Ellos no quieren demostrar nada, simplemente quieren decir ‘esto es lo que somos. Tenemos una vida dura pero también pasamos bueno’. Las temáticas son fuertes. El lenguaje es muy explícito. Se ufanan del consumo y expendio de drogas, de ‘sus’ mujeres y sus problemas con otros raperos”, dijo a Semana.com Sebastián Narváez, redactor de Noisey, el canal musical de Vice Colombia que acaba de producir una serie sobre este género.

Polémica

Las letras han generado un gran número de críticas y en algunos países varias emisoras han vetado diversas composiciones por considerar que hacen apología al crimen, al consumo de drogas y a la violencia de género.

“Estoy enamorado de la cocaína (...) Polvo de hornear, es polvo de hornear. Pásalo a través del cristal, negro. Estoy aspirando dinero rápido, negro”, canta CoCo en I’m in love with the coco, uno de los exponentes de este género en Estados Unidos. “Yo estoy claro de lo que de mi te han dicho, que lo tengo grande, y que bien rico chicho. Y dale métele, sólo por capricho sométele, motívate, agárralo con tu mano y verás que es algo sano”, dice Ozuna en La Ocasión junto a De La Ghetto, Anuel Aa y otros.

Trap de Puerto Rico.

Narváez explicó que el trap no tiene que ser necesariamente misógino o machista, hay algunas canciones que no pasan de lo erótico. Sin embargo, afirma el periodista, que muchos de los que cantan este género sí tienen esa visión de las mujeres.

“Yo quiero hacerte las 50 sombras de Grey, amarrarte de la cama con tape, comenzar a las 11 y terminar a las seis. Déjame empezar cuando yo quiera. Aquí no mandas tú, silencio, presta atención bandolera hoy a mucho placer te sentencio”, se oye en 50 sombras de Gray de Arcángel. En Panamá uno de los exponentes es Japanese: “de nuevo el rey de los pandas, mujeres dinero y parranda. A tu novia le damos su tanda, tú sabe en la calle el que manda. Crimen, banda, y nos mudamo’ pa’ Holanda”.

Para Alejandro Pino, magister en Estudios Culturales y director de Publimetro, es un error creer que un género musical es el culpable del machismo o la violencia de género, y no el producto de una sociedad machista que ve a las mujeres como objetos. “Esta música tiene la misma violencia simbólica que la música carrilera, el tex mex, la pornosalsa. Pero es más fácil criticar el reggaetón, por ejemplo, que ir a la raíz cultural del problema”, dice él.

De acuerdo con las afirmaciones anteriores, es evidente que el problema es estructural; la cultura es machista. Según Pino, la música, como cualquier expresión artística, es precisamente un reflejo de la realidad social; no sale de la nada. “Si vives en una sociedad machista y agresiva con las mujeres vas a tener canciones como las del Charrito Negro, Darío Darío o Maluma”. Lo mismo sucede con otras problemáticas como el narcotráfico o el uso de armas, otras temáticas centrales en este género en América Latina.

La defensa del género musical

El productor González dice que muchas de las críticas a los géneros urbanos vienen de personas que no tienen un mayor conocimiento del tema. “Cuando alguien, generalmente gente intelectual, me dice que el reggaetón es malo le pregunto: ‘¿Cuántos álbumes ha escuchado?, ¿100? ¿200 álbumes? ¿O por lo menos 100 canciones? Que no les guste es otra cosa, pero ¿cómo criticar todo un género y personas que dedican su vida a esto cuando no conocen realmente bien este tipo de música?”

Para González mucha gente critica desde la comodidad de las oportunidades. Pero no tienen en cuenta que los pioneros de estos géneros empezaron en los guetos y sus letras partían de lo que veían: “Son personas que crean con los elementos que tienen y muchos son muy creativos... Otra cosa es que ahora los artistas comerciales hayan visto en esto una oportunidad, cosa que pasa siempre”.

“La música es relativa no tanto a la composición sino al efecto – agrega B Clip- Hay cosas que están desafinadas, que no tienen una composición musical. Pero es la forma del gueto de expresarse. Es su creación y por tanto hay que respetarla. Así como se respeta a la gente que hace heavy metal, que hace cine gore o pinta cuadros de personas llenas de sangre. Esto es el arte del gueto”.

González también se pregunta por qué en vez de buscar censurar no se dan mejores oportunidades. Por qué aquellos que consideran machistas a un cantante de reggaetón le pagan menos a una mujer en la empresa precisamente por ser mujer.

Además, asegura que hay canciones que sí son de calidad en el trap como ball SO hard de Hucci; Tengo una mata de Químico ultra mega, Tú no vive así de Arcángel y Bad Bunny, Mosh Ft. Casino de Flosstradamus y Yamborghini high de Asap mob.

Por su parte Pino afirma que lo que hace falta es una transformación cultural que propenda por la igualdad de género, más que el debate de censurar una canción o no. “Somos una sociedad machista porque así nos hemos construido culturalmente, pero la institucionalidad poco hace por cambiarlo: de nada sirve una campaña contra la violencia a las mujeres si estamos educando niños para que crean que una mujer es sólo para servir al hombre, y no me refiero sólo a educación en la escuela, las familias tienen todo que ver y el avance de las iglesias cristianas también”.

Con todo -concluye Pino- ahora, que hoy tengamos reacciones frente a esa música también muestra que hay un cambio, al menos en un sector de la sociedad.
